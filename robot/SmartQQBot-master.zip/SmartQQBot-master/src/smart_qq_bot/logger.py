# -*- coding: utf-8 -*-
import logging

from smart_qq_bot.config import init_logging

logger = logging.getLogger("console logger")
init_logging(logger=logger)

