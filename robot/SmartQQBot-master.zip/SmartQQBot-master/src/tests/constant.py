# coding: utf-8

GROUP_RESPONSE = {
    "result":
        [
            {
                "poll_type": "group_message",
                "value": {
                    "content": [
                        [
                            "font",
                            {
                                "color": "000000",
                                "name": "微软雅黑",
                                "size": 10,
                                "style": [0, 0, 0]
                            }
                        ],
                        "赶快十条消息啊宝特",
                    ],
                    "from_uin": 2346434842,
                    "group_code": 2346434842,
                    "msg_id": 29820,
                    "msg_type": 0,
                    "send_uin": 3938506981,
                    "time": 1458377223,
                    "to_uin": 3155411624
                }
            }
        ],
    "retcode": 0
}
